require("./lib/myfunc.js");
const fs = require("fs");
const { TelegramClient, Api } = require("telegram");
const { StringSession } = require("telegram/sessions");
const input = require("input");
const { Telegraf } = require("telegraf");
const config = require("./config");

(async () => {
  console.log("=".repeat(50));
  console.log("🚀 AUTOORDER BOT STARTING...");
  console.log("=".repeat(50));

  let client = null;
  let bot = null;
  let userbotConnected = false;
  let botConnected = false;

  // ===== 1. COBA HUBUNGKAN USERBOT =====
  if (config.apiId && config.apiHash) {
    try {
      console.log("• Menghubungkan UserBot...");
      const session = fs.existsSync(config.sessionFile)
        ? fs.readFileSync(config.sessionFile, "utf8")
        : "";
      const stringSession = new StringSession(session);

      client = new TelegramClient(stringSession, config.apiId, config.apiHash, {
        connectionRetries: 4
      });

      await client.start({
        phoneNumber: async () => config.phoneNumber,
        password: async () => await input.text("🔐 Password 2FA (Enter jika tidak ada): \n"),
        phoneCode: async () => await input.text("📲 Kode verifikasi: \n"),
        onError: (err) => console.log("❌ UserBot Error:", err.message),
      });

      fs.writeFileSync(config.sessionFile, client.session.save());
      console.log("✅ UserBot Connected");
      userbotConnected = true;
      
      try {
        if (global.StartTelegram) {
          await global.StartTelegram(client, Api);
        }
        await client.getDialogs();
      } catch (err) {
        console.log("⚠️ Tidak bisa load dialogs:", err.message);
      }
    } catch (error) {
      console.log("❌ UserBot Gagal:", error.message);
      console.log("⚠️ Lanjut tanpa UserBot...");
      client = null;
    }
  } else {
    console.log("⚠️ API ID/Hash tidak ditemukan, skip UserBot");
  }

  // ===== 2. COBA HUBUNGKAN BOT =====
  if (config.botToken) {
    try {
      console.log("\n• Menghubungkan Bot Telegram...");
      bot = new Telegraf(config.botToken);

      bot.launch();

      // Set commands lengkap
      const userCommands = [
        { command: "menu", description: "Tampilkan Menu Utama" },
        { command: "start", description: "Mulai bot" },
        { command: "buypanel", description: "Beli Panel Pterodactyl" },
        { command: "buyadmin", description: "Beli Admin Panel Pterodactyl" },
        { command: "buyscript", description: "Beli Script" },        
        { command: "buyapps", description: "Beli Apps Premium" },
        { command: "buydo", description: "Beli Akun Digital Ocean" },
        { command: "buyvps", description: "Beli VPS Digital Ocean" },
        { command: "cekstok", description: "Cek Stok Tersedia" },
        { command: "profile", description: "Lihat Profile User" },
        { command: "history", description: "Riwayat Transaksi" }
      ];

      const ownerCommands = [
        { command: "backup", description: "Backup database" },
        { command: "broadcast", description: "Broadcast pesan ke semua user" },
        { command: "addscript", description: "Tambah script baru" },
        { command: "getscript", description: "Dapatkan script" },
        { command: "delscript", description: "Hapus script" },
        { command: "addstock", description: "Tambah stock apps" },
        { command: "delstock", description: "Hapus stock apps" },
        { command: "getstock", description: "Lihat stock apps" },
        { command: "addstockdo", description: "Tambah stock Digital Ocean" },
        { command: "delstockdo", description: "Hapus stock Digital Ocean" },
        { command: "getstockdo", description: "Lihat stock Digital Ocean" },
        { command: "userlist", description: "Daftar semua user" }
      ];

      // Set commands untuk semua user
      await bot.telegram.setMyCommands(userCommands);
      console.log("✅ User commands diatur");

      // Set commands untuk owner (jika ada ownerId)
      if (config.ownerId) {
        try {
          await bot.telegram.setMyCommands(
            [...userCommands, ...ownerCommands],
            { 
              scope: { 
                type: "chat", 
                chat_id: config.ownerId 
              }
            }
          );
          console.log("✅ Owner commands diatur");
        } catch (err) {
          console.log("⚠️ Tidak bisa set owner commands:", err.message);
        }
      }

      console.log("✅ Bot Connected");
      botConnected = true;

    } catch (error) {
      console.log("❌ Bot Gagal:", error.message);
      console.log("⚠️ Lanjut tanpa Bot...");
      bot = null;
    }
  } else {
    console.log("❌ Bot token tidak ditemukan!");
  }

  // ===== 3. CEK STATUS & LOAD MODULES =====
  console.log("\n" + "=".repeat(50));
  console.log("📊 STATUS KONEKSI:");
  console.log(`• UserBot: ${userbotConnected ? '✅ TERHUBUNG' : '❌ TIDAK AKTIF'}`);
  console.log(`• Bot: ${botConnected ? '✅ TERHUBUNG' : '❌ TIDAK AKTIF'}`);
  console.log("=".repeat(50));

  if (!userbotConnected && !botConnected) {
    console.log("💥 Tidak ada koneksi yang berhasil!");
    console.log("🔧 Periksa config.js dan restart.");
    process.exit(1);
  }

  // ===== 4. LOAD MODULES SESUAI KONEKSI =====
  try {
    if (bot && client) {
      // Keduanya terhubung
      require("./userbot")(client, bot);
      require("./bot")(bot);
      console.log("✅ Semua modules dimuat (Full mode)");
    } else if (bot && !client) {
      // Hanya Bot
      require("./bot")(bot);
      console.log("✅ Bot module dimuat (Bot-only mode)");
    } else if (!bot && client) {
      // Hanya UserBot
      require("./userbot")(client, null);
      console.log("✅ UserBot module dimuat (UserBot-only mode)");
      console.log("⚠️ Perintah bot tidak tersedia tanpa Bot token!");
    }
  } catch (error) {
    console.log("❌ Error loading modules:", error.message);
  }

  console.log("\n🎉 BOT READY!");
  console.log("💬 Gunakan /menu untuk memulai");
  console.log("🛑 Ctrl+C untuk berhenti");
  console.log("=".repeat(50));

  // ===== 5. GRACEFUL SHUTDOWN =====
  process.once('SIGINT', async () => {
    console.log("\n🛑 Menghentikan bot...");
    
    if (bot) {
      try {
        await bot.stop();
        console.log("✅ Bot dihentikan");
      } catch (e) {
        console.log("⚠️ Error stopping bot:", e.message);
      }
    }
    
    if (client) {
      try {
        await client.disconnect();
        console.log("✅ UserBot disconnected");
      } catch (e) {
        console.log("⚠️ Error disconnecting userbot:", e.message);
      }
    }
    
    console.log("👋 Goodbye!");
    process.exit(0);
  });

  process.once('SIGTERM', async () => {
    console.log("\n🛑 Received SIGTERM, shutting down...");
    
    if (bot) await bot.stop().catch(() => {});
    if (client) await client.disconnect().catch(() => {});
    
    process.exit(0);
  });

})();