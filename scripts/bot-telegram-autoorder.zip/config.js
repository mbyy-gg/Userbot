module.exports = {

 // ==== Bot Setting ========
  botToken: "-",
  botUsername: "-",
  menuImage: "https://img1.pixhost.to/images/11263/676832893_image.jpg",
  prefix: "/",
  ownerName: "Skyzopedia",
  ownerUsername: "Xskycode",
  ownerId: "7065253183",
  channelLink: "https://whatsapp.com/channel/0029VbBcgCK1SWstUXZnLh1o",
  
  // ===== Userbot Setting =====
  apiId: 1111111, // api_id Telegram
  apiHash: "-",
  phoneNumber: "-", 
  sessionFile: "./session.txt", 

  // "orderkuota" atau "pakasir"
  paymentGateway: "pakasir",

  // ===== Pakasir Config =====
  pakasir: {
    slug: "-",
    apiKey: "-"
  },

  // ===== OrderKuota Config =====
  orderkuota: {
    username: "-",
    token: "-"
  },

  // Info payment manual (opsional)
  payment: {
    qris: "https://files.catbox.moe/wri0uz.jpg",
    dana: "083164465401",
    ovo: "Tidak tersedia",
    gopay: "Tidak tersedia"
  },
  
  // Apikey Digitalocean
  apiDigitalOcean: "-", 
  
  // ===== Panel Config =====
  egg: "15",
  nestid: "5",
  loc: "1",
  domain: "https://skyy.zpr0.com",
  apikey: "ptla_A7jtHfNSG9xTmLC9ktnIDWxaDNtregHSFnshD3Ptf",
  capikey: "ptlc_57V554HeVxR4kxpL29Y1RGQV8KToKBPBsci8FHwo8", 
  
  // ===== Setting Api Subdomain ===
  subdomain: {
    "pterovip.my.id": {
      "zone": "4b262004a90e37c8656accb7087c4150",
      "apitoken": "wb4wjXwwdpIQ9Ezi_zfi0-0fWQD9BYYyTk-1ad4N"
    }, 
    "pteroweb.my.id": {
      "zone": "714e0f2e54a90875426f8a6819f782d0",
      "apitoken": "SbRAPRzC34ccmf4cJs-0qZ939yHe3Ko6CpolxqW4"
    },
    "panelwebsite.biz.id": {
      "zone": "2d6aab40136299392d66eed44a7b1122",
      "apitoken": "SbRAPRzC34ccmf4cJs-0qZ939yHe3Ko6CpolxqW4"
    },
    "privatserver.my.id": {
      "zone": "699bb9eb65046a886399c91daacb1968",
      "apitoken": "SbRAPRzC34ccmf4cJs-0qZ939yHe3Ko6CpolxqW4"
    },
    "serverku.biz.id": {
      "zone": "4e4feaba70b41ed78295d2dcc090dd3a",
      "apitoken": "SbRAPRzC34ccmf4cJs-0qZ939yHe3Ko6CpolxqW4"
    },
    "vipserver.web.id": {
      "zone": "e305b750127749c9b80f41a9cf4a3a53",
      "apitoken": "SbRAPRzC34ccmf4cJs-0qZ939yHe3Ko6CpolxqW4"
    }, 
    "mypanelstore.web.id": {
      "zone": "c61c442d70392500611499c5af816532",
      "apitoken": "SbRAPRzC34ccmf4cJs-0qZ939yHe3Ko6CpolxqW4"
    }
  }
  
};